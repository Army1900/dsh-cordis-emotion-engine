/**
 * 情绪引擎 Emotion Engine — Client 半部（dsh.client web 插件）
 *
 * 挂载本包自己的 Typert Remote（emotion/get、analyze、set），注册
 * shell.overlay 悬浮水波球，并通过 theme.overrideTokens 驱动全局变色。
 *
 * 说明：为保持独立可发布，本半部不依赖 @deepseek-ai 的 monorepo 内 client 包
 * （部分未发布到 npm），而是使用结构化类型；运行时这些服务由 DSH 部署提供。
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { EmotionKey } from '../index';
/** emotion.* Remote 面（RemoteResult 形状：{ ok, value }）。 */
export interface EmotionRemoteFace {
    get(): Promise<{
        ok: true;
        value: {
            mood: EmotionKey | null;
        };
    }>;
    analyze(sessionId: string): Promise<{
        ok: true;
        value: {
            mood: EmotionKey | null;
        };
    }>;
    set(args: {
        mood: EmotionKey | null;
    }): Promise<{
        ok: true;
        value: {
            ok: true;
        };
    }>;
}
/** Client 运行时面（结构化类型）。 */
export interface ClientCtx {
    get<T = unknown>(name: string): T | undefined;
    remote: {
        $mount(contribution: TypertRemoteContribution): Promise<unknown>;
    } & {
        emotion: EmotionRemoteFace;
    };
}
export declare const name = "dsh-cordis-emotion-engine";
/**
 * 只声明 'remote'：'remote.emotion' 是 $mount 后才注册的服务，
 * 若声明为 inject 会让 boot 阶段永久等待（pending）。
 * $mount 完成后通过 ctx.get('remote.emotion') 获取（ctx.get 不检查 inject）。
 */
export declare const inject: string[];
/**
 * Client 插件 apply 必须是同步函数（加载器不 await 返回值），
 * 因此 $mount（异步）完成后才注册 slots UI。
 */
export declare function apply(ctx: ClientCtx): void;
//# sourceMappingURL=index.d.ts.map