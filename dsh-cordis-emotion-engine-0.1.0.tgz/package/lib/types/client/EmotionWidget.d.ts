import type { EmotionKey } from '../index';
/** 主题服务面（只取用到的成员）。 */
export interface ThemeFace {
    overrideTokens(source: string, tokens: Record<string, {
        light: string;
        dark: string;
    }>): () => void;
}
/** Remote 方法返回 RemoteResult 形状：{ ok: true, value: T } | { ok: false, error }。 */
interface RemoteOk<T> {
    ok: true;
    value: T;
}
/** emotion Remote 命名空间服务（$mount 后注册为 ctx 'remote.emotion'，由 apply 传入）。 */
export interface EmotionRemote {
    get(): Promise<RemoteOk<{
        mood: EmotionKey | null;
    }>>;
    analyze(sessionId: string): Promise<RemoteOk<{
        mood: EmotionKey | null;
    }>>;
    set(args: {
        mood: EmotionKey | null;
    }): Promise<RemoteOk<{
        ok: true;
    }>>;
}
export interface EmotionWidgetProps {
    useSessions: (sel: (s: {
        current?: string;
    }) => string | undefined) => string | undefined;
    theme: ThemeFace;
    emotion: EmotionRemote;
}
/**
 * 水波悬浮球组件。
 */
export declare function EmotionWidget(props: EmotionWidgetProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=EmotionWidget.d.ts.map