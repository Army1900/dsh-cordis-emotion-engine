/**
 * 情绪引擎 Emotion Engine — Host 半部
 *
 * 标准 Cordis 插件：apply(ctx) 注册 EmotionService（Remote 服务，供 Client 半部
 * 通过 typert 网关调用），并注册 user-mood 系统提示词段落（每次模型调用动态
 * 注入当前用户情绪与回应引导）。
 *
 * 说明：Remote 标记使用手动绑定（Remote + methodContext），避免装饰器语法，
 * 保证构建产物为纯 JavaScript，可在任意 Node 环境加载。
 */
import { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
/** 五种情绪键。 */
export type EmotionKey = 'happy' | 'calm' | 'tired' | 'anxious' | 'angry';
/** Remote 结果载荷：当前情绪（null = 无情绪）。 */
export interface EmotionResult {
    mood: EmotionKey | null;
}
/** 情绪标签与提示词回应引导。 */
export declare const MOOD_INFO: Record<EmotionKey, {
    label: string;
    hint: string;
}>;
/**
 * 情绪 Remote 服务：Client 半部通过 typert 网关调用
 * `emotion/get`、`emotion/analyze`、`emotion/set`。
 */
export declare class EmotionService extends TypertRemoteService<{
    mood: EmotionKey | null;
}> {
    private _mood;
    constructor(ctx: Context);
    /** 当前情绪（系统提示词段落读取此值）。 */
    get mood(): EmotionKey | null;
    /** 读取当前情绪。 */
    get(): EmotionResult;
    /**
     * 分析指定会话最近 5 条用户消息，返回检测到的情绪（不写入当前状态，
     * 由 Client 决定是否 set）。
     */
    analyze(sessionId: string): Promise<EmotionResult>;
    /** 设置当前情绪（Client 同步自动/手动结果）。 */
    set(args: {
        mood: EmotionKey | null;
    }): {
        ok: true;
    };
}
/** Cordis 插件主体。 */
export declare const name = "dsh-cordis-emotion-engine";
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map