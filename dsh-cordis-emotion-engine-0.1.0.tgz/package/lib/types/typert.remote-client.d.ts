import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
export declare const PACKAGE = "dsh-cordis-emotion-engine";
/** 客户端挂载用 contribution。 */
export declare const TYPERT_REMOTE: TypertRemoteContribution;
export default TYPERT_REMOTE;
//# sourceMappingURL=typert.remote-client.d.ts.map